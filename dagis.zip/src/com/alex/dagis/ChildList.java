package com.alex.dagis;
import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;


public class ChildList extends JFrame {
	// Column in the table for the first name of child
	public static final int COLUMN_NAME = 0;
	// Column for the year when the children is born
	public static final int COLUMN_BORN_YEAR = 1;

	/**
	 * 
	 */ 
	private static final long serialVersionUID = 6117124528346991142L;
	public ChildList()
	{
		JPanel container = new JPanel();
		JTable table = new JTable();
		JScrollPane jsp = new JScrollPane(table);
		container.setLayout(new BorderLayout());
		
		table.setModel(new TableModel() {
			
			@Override
			public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
				// TODO Auto-generated method stub
				 
			}
			
			@Override
			public void removeTableModelListener(TableModelListener l) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public boolean isCellEditable(int rowIndex, int columnIndex) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public Object getValueAt(int rowIndex, int columnIndex) {
				// TODO Auto-generated method stub
				Child c = Dagis.dataSource.getChildren().get(rowIndex); // get the current childf
				switch(columnIndex)
				{
				case COLUMN_NAME:
					return c.getName();
				case COLUMN_BORN_YEAR:
					return c.year;
				}
				return null;
			}
			
			@Override
			public int getRowCount() {
				// TODO Auto-generated method stub
				// Return count of children
				return Dagis.dataSource.getChildren().size();
			}
			
			@Override
			public String getColumnName(int columnIndex) {
				// TODO Auto-generated method stub
				switch(columnIndex)
				{
				case COLUMN_NAME:
					return "Namn";
				case COLUMN_BORN_YEAR:
					return "F�delse�r";
				}
				return "";
			}
			
			@Override
			public int getColumnCount() {
				// TODO Auto-generated method stub
				return 2;
			}
			
			@Override
			public Class<?> getColumnClass(int columnIndex) {
				// TODO Auto-generated method stub
				switch(columnIndex)
				{
				case COLUMN_NAME:
					return String.class;
				case COLUMN_BORN_YEAR:
					return Integer.class;
				}
				return null;
			}
			
			@Override
			public void addTableModelListener(TableModelListener l) {
				// TODO Auto-generated method stub
				
			}
		});
		setPreferredSize(new Dimension(640,480));
		add(jsp);
		setSize(320,320);
	}
}
