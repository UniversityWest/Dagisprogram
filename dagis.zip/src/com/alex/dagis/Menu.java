package com.alex.dagis;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Collections;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.alex.dagis.data.DataSourceLoadException;


public class Menu extends JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5237335232850181080L;
	public Menu(){
		JPanel panel = new JPanel(new GridLayout(1,1));
	
		JButton addChild = new JButton("L�gg till barn");
		JButton listChildren = new JButton("Visa barn");
		panel.add(addChild);
		panel.add(listChildren);
		add(panel);
		listChildren.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				ChildList c = new ChildList();
				try {
					Dagis.dataSource.load();
					c.show();
				} catch (DataSourceLoadException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null, "Det gick inte att ladda filen. Felet var " + e1.getMessage());
				}
				
			}
		});
		addChild.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// TODO Auto-generated method stub
				AddChild frm = new AddChild();
				frm.show();
			}
		});
		setSize(new Dimension(640,480));
		
	}
}
