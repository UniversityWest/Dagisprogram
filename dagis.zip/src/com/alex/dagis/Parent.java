package com.alex.dagis;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;

/***
 * An parent to a child
 * @author Alex
 *
 */
public class Parent extends Person implements Serializable{
	public Parent()
	{
		
	}
	public Parent(int ssn)
	{
		this.mSSN=ssn;
	}
	/**
	 * Loads the list of parents into the memory
	 */
	public static void loadFile()
	{
		
	}
	
	
	private int mSSN;
	private String mAddress;
	private String mName;
	
	public String getAddress() {
		return mAddress;
	}
	public void setAddress(String mAddress) {
		this.mAddress = mAddress;
	}
	public int getSSN() {
		return mSSN;
	}
	public void setSSN(int mSSN) {
		this.mSSN = mSSN;
	}
	private ArrayList<Child> mChildren = new ArrayList<Child>();
	public ArrayList<Child> getChildren()
	{
		return mChildren;
	}
	public String getName() {
		return mName;
	}
	public void setName(String mName) {
		this.mName = mName;
	}
}
