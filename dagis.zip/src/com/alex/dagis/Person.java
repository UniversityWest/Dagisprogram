package com.alex.dagis;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
/***
 * An abstract class 'person'
 * @author Alexander
 *
 */
public abstract class Person {
	
}
