package com.alex.dagis;

public interface Serializable {

}