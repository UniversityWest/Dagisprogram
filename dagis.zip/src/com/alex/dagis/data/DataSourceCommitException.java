package com.alex.dagis.data;
/***
 * Exception raised on commit
 * @author Alexander
 *
 */
public class DataSourceCommitException extends DataSourceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 543160267543096858L;

	public DataSourceCommitException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

}
