package com.alex.dagis;

public class School {
	
}
